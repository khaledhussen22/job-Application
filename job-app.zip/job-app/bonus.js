/**
 * @param {number[]} nums
 * @return {boolean}
 */
var canJump = function(nums) {
    let maxReachable = 0;
    
    for (let i = 0; i < nums.length; i++) {
        if (i > maxReachable) return false; // If we can't reach index i, return false
        maxReachable = Math.max(maxReachable, i + nums[i]); // Update max reachable index
        if (maxReachable >= nums.length - 1) return true; // If we can reach the end, return true
    }
    
    return false;
};

// Example Test Case
console.log(canJump([2,3,1,1,4])); // true
console.log(canJump([3,2,1,0,4])); // false
