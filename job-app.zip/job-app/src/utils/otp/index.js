import nodemailer from "nodemailer";
import bcrypt from "bcrypt";

export const sendOTP = async ({ email, otp }) => {
  try {
    // Hash the OTP before storing it in the database
    const hashedOTP = await bcrypt.hash(otp, 10);

    // Configure transporter
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com", // SMTP host
      port: 587, // TLS encryption port
      secure: false, // True for port 465 (SSL), false for port 587 (TLS)
      auth: {
        user: process.env.EMAIL, // Sender email from environment variables
        pass: process.env.PASSWORD, // Sender email password
      },
    });

    // Prepare email details
    const mailOptions = {
      from: `"Your App Name" <${process.env.EMAIL}>`, // Sender's name and email
      to: email, // Recipient's email address
      subject: "Verify Your Email - OTP Code", // Subject line
      html: `
        <h2>Welcome to Your App!</h2>
        <p>Your One-Time Password (OTP) for account verification is:</p>
        <h1 style="color:blue;">${otp}</h1>
        <p>This OTP is valid for 10 minutes. Do not share it with anyone.</p>
      `,
    };

    // Send the email
    const info = await transporter.sendMail(mailOptions);

    // Check if the email was successfully sent
    if (info.rejected.length > 0) {
      console.error("Email rejected: ", info.rejected);
      return { success: false, message: "Email could not be sent" };
    }

    console.log("OTP Email sent successfully: ", info.response);
    return { success: true, hashedOTP }; // Return hashed OTP for database storage
  } catch (error) {
    console.error("Error sending OTP Email: ", error);
    return { success: false, message: "Failed to send OTP email" };
  }
};
