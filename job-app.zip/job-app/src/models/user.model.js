import { hash } from "bcrypt";
import { Schema,Types,model } from "mongoose";
import { hashing } from "../utils/hash/hash.js";
import { graphql } from "graphql";
import { encryption } from "../utils/index.js";

export const genders={
    Male:"male",
    M:"m",
    F:"f",
    FEMALE:"female"
};
Object.values(genders);//["male","female","m","f"]
Object.keys(genders);//["MALE","FEMALE",'M',"F"]

export const roles={
    USER:"user",
    ADMIN:"admin",
    SUPERADMIN:"superadmin",
    HR:"hr",
    OWNER:"owner",

}
export const defaultsecure_url="https://res.cloudinary.com/djz35z4qn/image/upload/v1738842683/default_hizha6.jpg" ;
export const  defaultpublic_id="default_hizha6";
const userSchema=new Schema(
    {
        email:{type:String,required:[true,"email is required"],unique:[true,"email already exist"],lowercase:true},
        password:{type:String,required:function(){
            return this.provider=="system"?true:false;
        },
    },
         firstName:{type:String,required:[true,"First name required"]},
         lastName:{type:String,required:[true,"last name required"]},
         companies:[{type:String,ref:"Company"}],
        phone:{type:String,
        required:function(){
            return this.provider=="system"?true:false;
        },
        unique:[true,"phone already"]},
        bannedAt: { type: Date, default: null },
        gender:{type:String,
            enum:Object.values(genders),
        },
        role:{type:String,enum:Object.values(roles),default:roles.USER},
        isDeleted:{type:Boolean,default:false},
        // profilePic:{type:String,default:"uploads/default.jpg"},
        profilePic:{secure_url:{type:String,default:defaultsecure_url,},
         public_id:{type:String,default: defaultpublic_id,}},

        friendRequests:[{type:Types.ObjectId,ref:"User"}],
        friends:[{type:Types.ObjectId,ref:"User"}],
        isConfirmed:{type:Boolean,default:false},
        deletedAt:{type:Date},
        provider:{type:String,enum:["google","system"],default:"system"},
        coverPic:[String],
        updatedBy:{type:Types.ObjectId,ref:"User"},
        DOB: {
            type: Date,
            
            validate: {
              validator: function (value) {
                const ageDiff = new Date().getFullYear() - value.getFullYear();
                return ageDiff >= 18;
              },
              message: "User must be at least 18 years old.",
            },
          },
          changeCredentialTime: { type: Date, default: null },
          OTP: [
            {
              code: { type: String, required: true },
              type: { type: String, enum: ["confirmEmail", "forgetPassword"], required: true },
              
            },
          ],
    },
    {
        timestamps:true
    }

);

userSchema
  .virtual("userName")
  .set(function (value) {
    this.firstName = value.split(" ")[0];
    this.lastName = value.split(" ")[1];
  })
  .get(function () {
    return this.firstName + "" + this.lastName;
  });

userSchema.pre("save",  function(next){
//document middleware>>this >>document
if(this.isModified("password"))
this.password= hashing({data:this.password})
return next();

});
userSchema.pre("save", function (next) {
    if (this.isModified("phone") && this.phone) {
        this.phone = encryption({ data: this.phone });
    }
    next();
});

export const User=model("User",userSchema)