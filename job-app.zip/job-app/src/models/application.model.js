import { model, Schema, Types } from "mongoose";

const ApplicationSchema=new Schema({
    jobId:{type:Types.ObjectId,required:true,ref:"Opportunity"},//
    userId:{type:Types.ObjectId,required:true,ref:"User"},//applier id
    userCV: {
        secure_url: {
          type: String,
        },
        public_id: {
          type: String, 
        },
      },
      status: {
        type: String,
        enum: ["pending", "accepted", "viewed", "in consideration", "rejected"], // Allowed status values
        default: "pending", // Default status
      },
},
    {timestamps:true})

    const Application=model("Application",ApplicationSchema)

    export default Application;