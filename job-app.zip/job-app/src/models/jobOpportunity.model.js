import { model, Schema, Types } from "mongoose";

const OpportunitySchema=new Schema({
    jobTitle:{type:String,required:true},
    jobLocation: {
        type: String,
        enum: ["onsite", "remotely", "hybrid"], // Restrict to these values
        required: true,
      },
      workingTime: {
        type: String,
        enum: ["part-time", "full-time"], // Only part-time or full-time allowed
        required: true,
      },
      seniorityLevel: {
        type: String,
        enum: ["Fresh", "Junior", "Mid-Level", "Senior", "Team-Lead", "CTO"], // Predefined seniority levels
        required: true,
      },
      jobDescription: {
        type: String,
        required: true,
      },
      technicalSkills: {
        type: [String], // Array of technical skills
        required: true,
      },
      softSkills: {
        type: [String], // Array of soft skills
      
      },
      addedBy: {
        type:Types.ObjectId,
        ref: "User", // Reference to HR who added the job
        required: true,
      },
      updatedBy: {
        type: Types.ObjectId,
        ref: "User", // Any HR related to the company can update
      },
      closed: {
        type: Boolean,
        default: false, // Default is open (false)
      },
      companyId: {
        type:Types.ObjectId,
        ref: "Company", // Reference to the company posting the job
        required: true,
      },

},{timestamps:true})

OpportunitySchema.virtual("applications", {
    ref: "Application",
    localField: "_id",
    foreignField: "jobId",
    justOne: false, // Fetch multiple applications
  });

const Jop=model("Jop",OpportunitySchema)

export default Jop;