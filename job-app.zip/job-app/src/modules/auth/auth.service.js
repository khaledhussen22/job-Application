import { User } from "../../models/user.model.js";
import { sendOTP } from "../../utils/otp/index.js";
import {
     asyncHandler, 
     compare, 
     encryption,
     generateToken,
     hashing, 
     messages,
     sendemail,
     verifyToken 
        } from "../../utils/index.js";
import Randomstring from "randomstring";


//register
export const signUp = async (req, res, next) => {
    try {
        const { email, password, phone, firstName, lastName } = req.body;

        // Generate a 6-digit OTP
        const otp = Math.floor(100000 + Math.random() * 900000).toString();

       

        // Send OTP to email
        const emailResponse = await sendOTP({ email, otp });
        if (!emailResponse.success) {
            return res.status(500).json({ message: "Failed to send OTP" });
        }
console.log(otp);

        // Store user data along with OTP
        await User.create({ 
            email, password, phone, firstName, lastName, 
            OTP: [{ code: otp, type: "confirmEmail" }]
        });

        res.status(201).json({ message: "OTP sent. Please verify your email." });
    } catch (error) {
        next(error);
    }
};
//email verfication
export const confirmOTP = async (req, res, next) => {
    try {
        const { email, otp } = req.body;

        // Find user by email
        const user = await User.findOne({ email });
        if (!user) return res.status(404).json({ message: "User not found" });

        // Find valid OTP
        const otpRecord = user.OTP.find(o => o.type === "confirmEmail");

        // Check if OTP exists and is not expired
        if (!otpRecord || otpRecord.expiresIn < new Date()) {
            return res.status(400).json({ message: "OTP expired or invalid" });
        }

        // Compare OTP (use bcrypt if OTPs are hashed)
        if (otp !== otpRecord.code) {
            return res.status(400).json({ message: "Invalid OTP" });
        }

        // Confirm user
        user.isConfirmed = true;
        user.OTP = []; // Clear OTPs after confirmation
        user.createdAt = Date.now();// Remove the TTL expiration
        await user.save();

        res.status(200).json({ message: "Email verified successfully" });
    } catch (error) {
        next(error);
    }
};
//login
export const signin =async(req,res,next)=>{
    const{email,password}=req.body

    const userExist=await User.findOne({email})

    if(!userExist){
        return next(new Error('user not exist',{cause:404}))
    }
const matched =compare({data:password,hashData:userExist.password})
if(!matched){
    return next(new Error('incorrect password',{cause:500}))
};
if(userExist.isConfirmed==false) return next(new Error("you must confirm you account frist"))
// if (!userExist.isConfirmed) {
//     return next(new Error('verify your emial',{cause:500}))
// }
if (userExist.isDeleted==true){
    await User.updateOne({_id:userExist._id},{isDeleted:false})
}
// const token =jwt.sign({email,id:userExist._id},process.env.SECRET_KEY);
const accessToken=generateToken({payload:{email,id:userExist._id},options:{expiresIn:"20d"}})
const refreshToken=generateToken({payload:{email,id:userExist._id},options:{expiresIn:"2h"}})


return res.status(200).json({
    message: "logged in succesfully",
    success:true,
    accessToken:accessToken,
    refreshToken:refreshToken,
})      
};
//generate refresh token
export const refreshTok=async(req,res,next)=>{
    //get data from req
    const {refreshToken}=req.body;
    //verify token
    const result =verifyToken({token:refreshToken})
    if(result.error) return next(result.error)
     
       const accesstoken= generateToken({
            payload:{email:result.email,id:result.id},
            options:{expiresIn:"1h"},
        })
return res.status(200).json({success:true,accesstoken})
}
// forgetpass
export const forgetpass = async (req, res, next) => {
    try {
      const { email } = req.body;
  
      // Find user
      const user = await User.findOne({ email });
      if (!user) return next(new Error(messages.user.notFound, { cause: 404 }));
  
      // Generate OTP
      const otp = Randomstring.generate({ length: 6, charset: "numeric" });
  
      
  
      // Store OTP in the user document
      user.OTP.push({
        code: otp,
        type: "forgetPassword",
      });
  
      // Save updated user with OTP
      await user.save();
  
      // Send OTP via email
      await sendOTP({ email, otp }); // Make sure sendOTP function exists
  
      return res.status(200).json({
        success: true,
        message: "otp for forget password created succesfully",
      });
    } catch (error) {
      next(error);
    }
  };
  //reset password
  export const reset=async(req,res,next)=>{

    const {email,otp,password,cPassword}=req.body
    const user = await User.findOne({ email });
if (!user) return next(new Error(messages.user.notFound, { cause: 404 }));

// Find the OTP inside the user's OTP array
const otpExist = user.OTP.find(o => o.code === otp && o.type === "forgetPassword");

if (!otpExist) return next(new Error(messages.otp.notFound, { cause: 404 }));

            user.password=password
            await user.save()

            return res.json({success:true,message:"try to login now"})

}