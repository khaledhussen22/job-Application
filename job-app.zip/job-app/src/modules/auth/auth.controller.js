import { Router } from "express";
import { isauth } from "../../middleware/authentication.middleware.js";
import { isAuthorized } from "../../middleware/authorization.middleware.js";
import { roles } from "../../models/user.model.js";
import * as authSchemas from "./auth.validation.js";
import * as authServices from "./auth.service.js";
import { asyncHandler } from "../../utils/index.js";

const router= new Router();
//sign up
router.post("/signup",asyncHandler(authServices.signUp))
//to verify email
router.post("/confirmation",asyncHandler(authServices.confirmOTP))
//sign in 
router.post("/signin",asyncHandler(authServices.signin))
//refresh token
router.post("/refreshToken",asyncHandler(authServices.refreshTok))
//forget password
router.post("/forgetpass",asyncHandler(authServices.forgetpass))
//reset password
router.post("/reset",asyncHandler(authServices.reset))
//google login



export default router;