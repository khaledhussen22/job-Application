import Application from "../../models/application.model.js";
import Company from "../../models/company.model.js";
import Jop from "../../models/jobOpportunity.model.js";
import { sendemail } from "../../utils/index.js";
//create job
export const addJob=async(req,res,next)=>{
  const {companyId}=req.params
    const company=await Company.findOne({_id:companyId})
    if(!company) return next (new Error("no company found"))
      //only owner and HR who can add jobs
    if(company.HRs.includes(req.userExist._id) && req.userExist._id!= company.createdBy )
        return next (new Error("you are not authorized to make this"))
    const {
        jobTitle,
        jobLocation,
        workingTime,
        seniorityLevel,
        jobDescription,
        technicalSkills,
        
    }=req.body;

   const JOB= await Jop.create({
    jobTitle,
    jobLocation,
    workingTime,
    seniorityLevel,
    jobDescription,
    technicalSkills,
    addedBy:req.userExist._id,
    companyId
   })
   const company2 = await Company.findOneAndUpdate(
    { _id: companyId }, // Find the company by ID
    { $push: { avialableJobs: JOB._id } }, // Push the jobId into jobsRelated array
    { new: true, upsert: false } // Return updated document & prevent creating if not found
  );
  
   return res.status(200).json({success:true,message:"job added successfully",JOB})

}
//update job
export const updateJob = async (req, res, next) => {
    const { jobId } = req.params;

    // Find and update the job
    const job = await Jop.findOneAndUpdate(
        { _id: jobId }, 
        { $set: req.body }, // ✅ Correct update format
        { new: true } // ✅ Ensures updated document is returned
    ).populate({
        path: "companyId",
        select: "createdBy companyName" // ✅ Only fetches `createdBy` & `companyName`
    });
 const companyOwner=job.companyId?.createdBy
console.log(companyOwner);

 if(companyOwner.toString()!==req.userExist._id.toString()) return next (new Error("you are not authorized"))
    // Check if job exists
    if (!job) {
        return next(new Error("Job not found", { cause: 404 }));
    }

    return res.status(200).json({ success: true, job });
};
//delete job
export const deleteJob=async(req,res,next)=>{
    const {jobId}=req.params;
    const job = await Jop.findOne({ _id: jobId })
    .populate({
        path: "companyId",
        populate: {
            path: "HRs", // ✅ This will populate the HRs array in the Company model
            model: "User", // ✅ Ensures it fetches User details
            select: "name email role" // ✅ Select only required fields
        }
    });

    const userId = req.userExist._id.toString();
    const companyHRs = job.companyId?.HRs.map(hr => hr._id.toString()) || [];

 console.log(userId);
 console.log(companyHRs);
 
 
    if ( !companyHRs.includes(userId)) {
        return next(new Error("You are not authorized"));
    }
    if(!job)
          return next (new Error("no job found"))

    //delete job 
    await Jop.deleteOne({ _id: jobId });
    return res.status(200).json({ success: true, message: "Job deleted successfully" });
}
//get all jobs or specifi job for a company

export const getJobsByCompany = async (req, res, next) => {
        
            const { companyId, jobId } = req.params;
            const { page = 1, limit = 10, sort = "createdAt", search, companyName } = req.query;
    
            const skip = (parseInt(page) - 1) * parseInt(limit);
    
           
            let company;
            if (companyName) {
                company = await Company.findOne({ companyName: { $regex: companyName, $options: "i" } });
                if (!company) return next(new Error("Company not found"));
            }
    
        
            let query = { companyId: company ? company._id : companyId };
    
         
            if (jobId) {
                query._id = jobId;
            }
    
            if (search) {
                query.jobTitle = { $regex: search, $options: "i" }; // Case-insensitive search
            }
            const totalCount = await Jop.countDocuments(query);
    
            
            const jobs = await Jop.find(query)
                .populate("companyId", "companyName address industry") // Populate company details
                .sort({ [sort]: -1 }) 
                .skip(skip)
                .limit(parseInt(limit));
    
            return res.status(200).json({
                success: true,
                totalCount,
                currentPage: parseInt(page),
                totalPages: Math.ceil(totalCount / limit),
                jobs,
            });
     
        
    };
    //get filtered jobs
export const getFilteredJobs = async (req, res, next) => {
       
            const { 
                page = 1, 
                limit = 10, 
                sort = "createdAt", 
                workingTime, 
                jobLocation, 
                seniorityLevel, 
                jobTitle, 
                technicalSkills 
            } = req.query;
    
            const skip = (parseInt(page) - 1) * parseInt(limit);
    
            let query = {};
    
            if (workingTime) query.workingTime = workingTime;
            if (jobLocation) query.jobLocation = jobLocation;
            if (seniorityLevel) query.seniorityLevel = seniorityLevel;
    
            if (jobTitle) {
                query.jobTitle = { $regex: jobTitle, $options: "i" }; // Case-insensitive search
            }
    
            if (technicalSkills) {
                const skillsArray = technicalSkills.split(","); 
                query.technicalSkills = { $in: skillsArray }; 
            }
    
    
            const totalCount = await Jop.countDocuments(query);
    
  
            const jobs = await Jop.find(query)
                .populate("companyId", "companyName address industry") 
                .sort({ [sort]: -1 })
                .skip(skip)
                .limit(parseInt(limit));
    
            return res.status(200).json({
                success: true,
                totalCount,
                currentPage: parseInt(page),
                totalPages: Math.ceil(totalCount / limit),
                jobs,
            });
       
    };
//get application for job
export const getJobApplications = async (req, res, next) => {
    
        const { jobId } = req.params;
        const { page = 1, limit = 10, sort = "createdAt" } = req.query;

        const skip = (parseInt(page) - 1) * parseInt(limit);

    
        const job = await Jop.findById(jobId)
            .populate({
                path: "companyId",
                select: "createdBy HRs",
            })
            .populate({
                path: "applications",
                populate: {
                    path: "userId",
                    select: "name email phone resume",
                },
                options: {
                    sort: { [sort]: -1 }, 
                    skip: skip,
                    limit: parseInt(limit),
                }
            });

        if (!job) return next(new Error("Job not found"));

    
        const userId = req.userExist._id.toString();
        const companyOwner = job.companyId?.createdBy.toString();
        const companyHRs = job.companyId?.HRs.map(hr => hr.toString()) || [];

        if (userId !== companyOwner && !companyHRs.includes(userId)) {
            return next(new Error("You are not authorized"));
        }

        return res.status(200).json({
            success: true,
            jobTitle: job.jobTitle,
            totalApplications: job.applications.length,
            currentPage: parseInt(page),
            totalPages: Math.ceil(job.applications.length / limit),
            applications: job.applications, 
        });

 
};
// 7. Apply to Job (Job application) 
// i made it in application module


//reject or accepted
export const updateApplicationStatus = async (req, res, next) => {
    try {
      const { applicationId } = req.params;
      const { status } = req.body;
      const userId = req.userExist._id.toString();
  
     
      if (!["accepted", "rejected"].includes(status)) {
        return next(new Error("Invalid status. Allowed values: 'accepted' or 'rejected'"));
      }
  
     
      const application = await Application.findById(applicationId).populate({
        path: "jobId",
        populate: { path: "companyId", select: "HRs createdBy" },
      });
  
      if (!application) return next(new Error("Application not found"));
  
      const job = application.jobId;
      const company = job.companyId;
  
      if (!company) return next(new Error("Company not found"));
  

      const isHRorOwner =
        company.createdBy.toString() === userId || company.HRs.some((hr) => hr.toString() === userId);
  
      if (!isHRorOwner) {
        return next(new Error("You are not authorized to update this application"));
      }
  
      
      application.status = status;
      await application.save();
  
      
      const applicantEmail = application.userId.email;
  
      const subject = status === "accepted" ? "Congratulations! You’re Hired 🎉" : "Application Update";
      const message =
        status === "accepted"
          ? `Dear Applicant,\n\nCongratulations! Your application for the position of ${job.title} has been accepted.`
          : `Dear Applicant,\n\nWe regret to inform you that your application for the position of ${job.title} has been rejected.`;
  
      await sendemail(applicantEmail, subject, message);
  
      return res.status(200).json({
        success: true,
        message: `Application ${status} successfully`,
        application,
      });
    } catch (error) {
      next(error);
    }
  };



