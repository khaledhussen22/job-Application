import { Router } from "express";
import * as jobServices from "./job.services.js"
import * as jobValidation from "./job.validation.js"
import { isauth } from "../../middleware/authentication.middleware.js";
import { asyncHandler } from "../../utils/index.js";
import { isAuthorized } from "../../middleware/authorization.middleware.js";
import { roles } from "../../models/user.model.js";
const router=new Router();9
//add job
router.post("/addjob/:companyId",isauth,asyncHandler(jobServices.addJob))
//update job
router.post("/update/:jobId",isauth,asyncHandler(jobServices.updateJob))
//DELETE JOB
router.delete("/delete/:jobId",isauth,asyncHandler(jobServices.deleteJob))
//get specific job
router.get("/:companyId/jobs/:jobId?", asyncHandler(jobServices.getJobsByCompany));
//get filtered jobs
router.get("/jobs", asyncHandler(jobServices.getFilteredJobs));
//get application for a job
router.get("/:jobId/applications", isauth,isAuthorized(roles.USER), asyncHandler(jobServices.getJobApplications));
//accepted or rejected
router.post("/:applicationId ",isauth,asyncHandler(jobServices.updateApplicationStatus))

export default router;