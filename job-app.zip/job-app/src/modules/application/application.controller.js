import { Router } from "express";
import { cloudUpload, fileValidation } from "../../utils/file upload/multer cloud.js";
import * as applicationService from "./application.service.js"; 
import { isauth } from "../../middleware/authentication.middleware.js";
import { asyncHandler } from "../../utils/index.js";
const router=Router();

router.post(
    "/:jobId/apply",
     isauth,
      cloudUpload (fileValidation.images).single("userCV"), 
      asyncHandler(applicationService.apply));



export default router;