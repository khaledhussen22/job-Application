import Application from "../../models/application.model.js";
import path from "path";
import cloudinary from "../../utils/file upload/cloudinary.config.js";
import Jop from "../../models/jobOpportunity.model.js";

export const apply = async (req, res, next) => {
    
        const { jobId } = req.params;

        // ✅ Check if CV file is provided
        if (!req.file) return next(new Error("CV is required"));

        // ✅ Check if the job exists
        const job = await Jop.findById(jobId);
        if (!job) return next(new Error("Job not found"));

        // ✅ Check if the user has already applied
        const existingApplication = await Application.findOne({
            jobId,
            userId: req.userExist._id,
        });

        if (existingApplication) {
            return next(new Error("You have already applied for this job"));
        }

        // ✅ Upload CV to Cloudinary
        const { secure_url, public_id } = await cloudinary.uploader.upload(req.file.path, {
            folder: `exam/application/${req.userExist._id}/cv`,
        });

        // ✅ Create a new application
        const application = await Application.create({
            jobId,
            userId: req.userExist._id,
            userCV: { secure_url, public_id }, // Store CV details
        }); 

        // ✅ Return success response
        return res.status(201).json({
            success: true,
            message: "Application submitted successfully",
            application,
        });
    }