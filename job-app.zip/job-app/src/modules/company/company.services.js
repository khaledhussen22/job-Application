import { populate } from "dotenv"
import Company from "../../models/company.model.js"
import cloudinary from "../../utils/file upload/cloudinary.config.js"
import { User } from "../../models/user.model.js"
import path from "path";

//add compant
export const addCompany=async(req,res,next)=>{
    let{ industry, companyName,description,address,companyEmail,createdBy,numberOfEmployees}=req.body
const company =await Company.create({
    companyName,
    description,
    address,
    companyEmail,
    createdBy,
    industry,
    numberOfEmployees})
 
    await User.findByIdAndUpdate(
        createdBy, 
        { $push: { companies: company._id },$set: { role: "owner" } }, 
        { new: true }
    );
  

return res.status(200).json({success:true,data:company})

  
}
export const updateCompany = async (req, res, next) => {
    
        const { companyId } = req.params;
        const updateFields = { ...req.body }; // Extract fields from body

        // Find the company first to verify the owner
        const company = await Company.findById(companyId);
        if (!company) return next(new Error("Company not found"));

        // Check if the user making the request is the owner
        if (company.createdBy.toString() !== req.userExist._id.toString()) {
            return next(new Error("You are not authorized to update this company"));
        }

        // Update the company
        const updatedCompany = await Company.findByIdAndUpdate(
            companyId,
            { $set: updateFields }, // ✅ Only update provided fields
            { new: true, runValidators: true }
        );

        return res.status(200).json({ success: true, company: updatedCompany });
    
};
//upload logo
export const uploadLogo = async (req, res, next) => {
    try {
      // Validate if a file is uploaded
      if (!req.file) {
        return res.status(400).json({ success: false, message: "Logo image is required" });
      }
  
      // Validate if user has a company
      if (!req.userExist.companies || req.userExist.companies.length === 0) {
        return res.status(400).json({ success: false, message: "User has no associated companies" });
      }
  
      // Get the first company ID (adjust logic if needed)
      const companyId = req.userExist.companies[0]; 
  
  
      // Check if the company exists
      const company = await Company.findById(companyId);
      if (!company) {
        return res.status(404).json({ success: false, message: "Company not found" });
      }
  
      // Delete old logo if it exists
      if (company.logo?.public_id) {
        await cloudinary.uploader.destroy(company.logo.public_id);
      }
  
      // Upload new logo
      const { secure_url, public_id } = await cloudinary.uploader.upload(req.file.path, {
        folder: `exam/company/${companyId}/logo`,
      });
  
      console.log("Uploaded Logo URL:", secure_url); // Debugging log
  
      // Update company document
      const updatedCompany = await Company.findByIdAndUpdate(
        companyId,
        { $set: { logo: { secure_url, public_id } } }, // Use $set to update
        { new: true, runValidators: true }
      );
  
      console.log("Updated Company:", updatedCompany); // Debugging log
  
      if (!updatedCompany) {
        return res.status(500).json({ success: false, message: "Failed to update company logo" });
      }
  
      return res.status(200).json({ success: true, data: updatedCompany });
  
    } catch (error) {
      console.error("Upload Logo Error:", error); // Debugging log
      return res.status(500).json({ success: false, message: error.message });
    }
  };
  //delete logo
  export const deleteProf=async(req,res,next)=>{
    const companyId = req.userExist.companies[0]; 
   const company=await Company.findById(companyId)

      if (!company) {
          return res.status(404).json({ success: false, message: "company not found" });
      }
          
          // Delete profile picture from Cloudinary
          await cloudinary.uploader.destroy(company.logo.public_id);
  
          // Reset profile picture to default
          company.logo = {
              secure_url: defaultsecure_url,
              public_id: defaultpublic_id,
          };
  
          await Company.save(); // Save updated user data
  
          return res.status(200).json({
              success: true,
              message: "logo picture deleted successfully",
              data: company,
          });
  }
  //search api (case insensetive)
  export const searchCompanyByName = async (req, res, next) => {
    try {
      const { companyName } = req.body;
  
      if (!companyName) {
        return res.status(400).json({ success: false, message: "Company name is required for search" });
      }
  
      // Case-insensitive search for partial matches
      const companies = await Company.find({
        companyName: { $regex: companyName, $options: "i" }
      });
  
      if (companies.length === 0) {
        return res.status(404).json({ success: false, message: "No companies found" });
      }
  
      return res.status(200).json({ success: true, data: companies });
    } catch (error) {
      console.error("Search Company Error:", error);
      return res.status(500).json({ success: false, message: "Server error" });
    }
  };
//soft delete
export const softDelete=async(req,res,next)=>{
    const {companyId}=req.params;

  
    const company = await Company.findByIdAndUpdate(
        companyId,
        { deletedAt: new Date() }, // Soft delete by setting a timestamp
        { new: true } // Return the updated document
      );
   if(req.userExist.role!=ADMIN ||req.userExist.id!=company.createdAt)
    return next(new Error("you are not authorized"))
    if (!company) {
        return res.status(404).json({ success: false, message: "Company not found" });
      }
    return res.status(200).json({success:true,message:"user deleted successfully"})
}
//get specific company with related jobs
export const getspecificCompanywithJobs=async(req,res,next)=>{
    const {companyId}=req.params;
    const company=await Company.findById(companyId).populate("avialableJobs");
    
    
    if(!company) return next (new Error("company not found"))
        return res.status(200).json({ success: true, company });
}
  
  
  