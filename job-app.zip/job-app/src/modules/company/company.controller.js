import { Router } from "express";
import * as companyServices from "./company.services.js"
import * as companyValidation from "./company.validation.js"
import { isauth } from "../../middleware/authentication.middleware.js";
import { asyncHandler } from "../../utils/index.js";
import { isValid } from "../../middleware/validation.middelware.js";
import { cloudUpload, fileValidation } from "../../utils/file upload/multer cloud.js";
import { isAuthorized } from "../../middleware/authorization.middleware.js";
import { roles } from "../../models/user.model.js";
const router =new Router();
//add company
router.post("/add",isauth,isValid(companyValidation.addCompany),asyncHandler(companyServices.addCompany))
//update company
router.post("/update/:companyId",isauth,asyncHandler(companyServices.updateCompany))
//upload logo
router.post(
    "/logo",
    isauth,
    cloudUpload (fileValidation.images).single("image"), 
    asyncHandler(companyServices.uploadLogo),
)
//delete logo
router.delete(
    "/deletelogo",
    isauth,
    asyncHandler(companyServices)
)
//search by name
router.get(
    "/search",
    isauth,
    isValid(companyValidation.searchCompany),
    asyncHandler(companyServices.searchCompanyByName)
)
//soft delete (manually authorized)
router.put("/softdel/:companyId",isauth,asyncHandler(companyServices.softDelete))
//getspecificCompanywithJobs
router.get("/:companyId",isauth,asyncHandler(companyServices.getspecificCompanywithJobs))


export default router;
