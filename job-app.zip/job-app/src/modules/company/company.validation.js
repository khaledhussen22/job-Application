import joi from "joi";
import { generalFields } from "../../middleware/validation.middelware.js";

export const addCompany=joi.object({
    companyName:joi.string().required(),
    description:joi.string(),
    address:joi.string().required(),
    companyEmail:joi.string().email().required(),
    createdBy:generalFields.id.required(),
    industry:joi.string(),
    numberOfEmployees:joi.number().min(10).max(20).required(),
    
}).required()

export const searchCompany=joi.object({
    companyName:joi.string().required(),
}).required()