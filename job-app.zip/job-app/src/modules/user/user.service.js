import { defaultpublic_id, defaultsecure_url, User } from "../../models/user.model.js";
import { decrypt } from "../../utils/crypto/decrypt.js"
import cloudinary from "../../utils/file upload/cloudinary.config.js";
import path from "path";

//update user
export const updateUser=async (req,res,next)=>{
    const { phone, DOB ,firstName, lastName, gender}=req.body
    const user= await User.findById(req.userExist._id)
    if(!user) return next(new Error(messages.user.notFound,{cause:404}))
    user.firstName=firstName;
    user.lastName=lastName;
    user.phone=phone;
    user.gender=gender;
    user.DOB=DOB;
   await  user.save();
   return res.status(200).json({success:true,message:"user updated successfully"})
  };
//logged in data
  export const loggedindata=async(req,res,next)=>{
  
    const user=await User.findOne(req.userExist._id)
      const phone=user.phone;
      const firstName=user.firstName
      const lastName=user.lastName
      const email=user.email

    return res.status(200).json({success:true,
        data:
        {
            phone:decrypt({data:phone}),
            firstName,
            lastName,
            email
        }})
  };
  //get profile data for another user
  export const getProfileOfUser=async(req,res,next)=>{
    const{_userId}=req.body;
    const user=await User.findOne(_userId);
    let { firstName,lastName,phone, profilePic, coverPic }=user;
    return res.status(200).json({success:true,data:
        {
            phone:decrypt({data:phone}),
            firstName,
            lastName,
            profilePic,
            coverPic,
        }

    })


  }
  //upload profile pic
  export const uploadProfilePic=async(req,res,next)=>{
     //delete old prof pic
 await cloudinary.uploader.destroy(req.userExist.profilePic.public_id)

 const {secure_url,public_id}=  await cloudinary.uploader.upload(req.file.path,{
   folder:`exam/users/${req.userExist._id}/profile-pic`,
 })
 
 const user= await User.findByIdAndUpdate(req.userExist._id,{profilePic:{secure_url,public_id}})
 return res.status(200).json({success:true,data:user})
 

  }
//delete profPic
export const deleteProf=async(req,res,next)=>{
    const user = await User.findById(req.userExist._id);
    if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
    }
         // Check if the user has a profile picture
         if (!user.profilePic || !user.profilePic.public_id) {
            return res.status(400).json({ success: false, message: "No profile picture to delete" });
        }

        // Delete profile picture from Cloudinary
        await cloudinary.uploader.destroy(user.profilePic.public_id);

        // Reset profile picture to default
        user.profilePic = {
            secure_url: defaultsecure_url,
            public_id: defaultpublic_id,
        };

        await user.save(); // Save updated user data

        return res.status(200).json({
            success: true,
            message: "Profile picture deleted successfully",
            data: user,
        });
}
//upload cover pic
export const uploadCoverPic = async (req, res, next) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ success: false, message: "No cover pictures uploaded" });
        }

        // Upload images to Cloudinary and store their URLs
        let coverPics = [];
        for (const file of req.files) {
            const result = await cloudinary.uploader.upload(file.path, {
                folder: `exam/users/${req.userExist._id}/cover-pic`,
            });
            coverPics.push(result.secure_url);
        }

        // Update user's coverPic field in the database
        const user = await User.findByIdAndUpdate(req.userExist._id, { coverPic: coverPics }, { new: true });

        return res.status(200).json({ success: true, message: "Cover pictures uploaded successfully", data: user });
    } catch (error) {
        next(error);
    }
};
//delete cover pic

export const deleteCoverPic = async (req, res, next) => {
    try {
        const { imageUrl } = req.body; // The URL of the image to delete
        if (!imageUrl) {
            return res.status(400).json({ success: false, message: "Image URL is required" });
        }

        // Find user and check if the image exists in their coverPic array
        const user = await User.findById(req.userExist._id);
        if (!user) {
            return res.status(404).json({ success: false, message: "User not found" });
        }

        const coverPics = user.coverPic;
        if (!coverPics.includes(imageUrl)) {
            return res.status(400).json({ success: false, message: "Image not found in user's cover pictures" });
        }

        // Extract public_id from Cloudinary URL
        const publicId = imageUrl.split("/").pop().split(".")[0]; // Extracts last part before ".jpg" or ".png"

        // Delete image from Cloudinary
        await cloudinary.uploader.destroy(`exam/users/${user._id}/cover-pic/${publicId}`);

        // Remove image URL from user's coverPic array
        const updatedCoverPics = coverPics.filter(pic => pic !== imageUrl);
        const updatedUser = await User.findByIdAndUpdate(req.userExist._id, { coverPic: updatedCoverPics }, { new: true });

        return res.status(200).json({ success: true, message: "Cover picture deleted successfully", data: updatedUser });

    } catch (error) {
        next(error);
    }
};
//soft delete
export const softDelete=async(req,res,next)=>{
    const user=await User.findOneAndUpdate({_id:req.userExist._id},{isDeleted:true});
   if(!user) return next(new Error("user not found"))
    if(user.isDeleted==true) return next(new Error("user already deleted"))

        return res.status(200).json({success:true,message:"user deleted successfully"})
}



