import { Router } from "express";
import { isauth } from "../../middleware/authentication.middleware.js";
import * as userServices from "./user.service.js"
import { asyncHandler } from "../../utils/index.js";
import { fileValidation } from "../../utils/file upload/multer.js";
import { cloudUpload } from "../../utils/file upload/multer cloud.js";
const router=new Router();
//update user
router.post("/update",isauth,userServices.updateUser)
//logged in user data
router.get("/loggedData",isauth,asyncHandler(userServices.loggedindata))
//get user profile data
router.get("/getuserdata",isauth,asyncHandler(userServices.getProfileOfUser))
//upload profilePic
router.post(
    "/profilePic",
    isauth,
    cloudUpload (fileValidation.images).single("image"), 
    asyncHandler(userServices.uploadProfilePic),
)
//delete profile pic
router.post(
    "/deleteProf",
    isauth,
    asyncHandler(userServices.deleteProf)
)
//upload cover pics
router.post(
    "/coverPics",
    isauth,
    cloudUpload (fileValidation.images).array("images"), 
    asyncHandler(userServices.uploadCoverPic),
)
//delete cover pic
router.delete(
    "/coverPic",
    isauth,
    asyncHandler(userServices.deleteCoverPic)
)
//soft delete
router.delete("/softdel",isauth,asyncHandler(userServices.softDelete))



export default router;