import { GraphQLObjectType, GraphQLSchema, GraphQLList, GraphQLID, GraphQLString, GraphQLBoolean } from "graphql";
import {User} from "../models/user.model.js"
import Company from "../models/company.model.js";
export const UserType = new GraphQLObjectType({
    name: "User",
    fields: () => ({
      id: { type: GraphQLID },
      firstName: { type: GraphQLString },
      lastName: { type: GraphQLString },
      email: { type: GraphQLString },
      phone: { type: GraphQLString },
      role: { type: GraphQLString },
      isBanned: { type: GraphQLBoolean },
    }),
  });
  
  // Define Company Type
  export const CompanyType = new GraphQLObjectType({
    name: "Company",
    fields: () => ({
      id: { type: GraphQLID },
      companyName: { type: GraphQLString },
      industry: { type: GraphQLString },
      companyEmail: { type: GraphQLString },
      approvedByAdmin: { type: GraphQLBoolean },
      bannedAt: { type: GraphQLString },
    }),
  });
  