import { GraphQLObjectType, GraphQLSchema, GraphQLList, GraphQLID, GraphQLString, GraphQLBoolean } from "graphql";
import {User} from "../models/user.model.js"
import Company from "../models/company.model.js";
import { CompanyType, UserType } from "./graphql.types.js";



const RootQuery = new GraphQLObjectType({
  name: "Query",
  fields: {
    getAllData: {
      type: new GraphQLObjectType({
        name: "DataResponse",
        fields: {
          users: { type: new GraphQLList(UserType) },
          companies: { type: new GraphQLList(CompanyType) },
        },
      }),
      resolve: async () => {
        const users = await User.find();
        const companies = await Company.find();
        return { users, companies };
      },
    },
  },
});


const Mutation = new GraphQLObjectType({
  name: "Mutation",
  fields: {
    banUser: {
      type: UserType,
      args: { userId: { type: GraphQLID } },
      resolve: async (_, { userId }) => {
        return await User.findByIdAndUpdate(userId, { bannedAt: new Date() }, { new: true });
      },
    },
    unbanUser: {
      type: UserType,
      args: { userId: { type: GraphQLID } },
      resolve: async (_, { userId }) => {
        return await User.findByIdAndUpdate(userId, { bannedAt: null }, { new: true });
      },
    },
    banCompany: {
      type: CompanyType,
      args: { companyId: { type: GraphQLID } },
      resolve: async (_, { companyId }) => {
        return await Company.findByIdAndUpdate(companyId, { bannedAt: new Date() }, { new: true });
      },
    },
    unbanCompany: {
      type: CompanyType,
      args: { companyId: { type: GraphQLID } },
      resolve: async (_, { companyId }) => {
        return await Company.findByIdAndUpdate(companyId, { bannedAt: null }, { new: true });
      },
    },
    approveCompany: {
      type: CompanyType,
      args: { companyId: { type: GraphQLID } },
      resolve: async (_, { companyId }) => {
        return await Company.findByIdAndUpdate(companyId, { approvedByAdmin: true }, { new: true });
      },
    },
  },
});


export const schema = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});
